# OneAgent role

## Requirements

* OneAgent version 1.203+
* Dynatrace version 1.204+
* Script access to OneAgent installer files

## Deploy OneAgents

 To provide the script with access to the appropriate OneAgent installer files, you can either:
 * configure the script to download the installer files directly from your Dynatrace environment or
 * you can download them yourself using the Dynatrace web UI and upload them manually to the control node. This provides the script with local copies of the installers. 

### Option 1: Use direct download from Dynatrace environment

The script utilizes [Deployment API] to download the platform-specific installers to the managed nodes.
You will need to specify the variables to supply the role with the information required to authenticate the API call in your environment:

* The environment URL:
  * **SaaS**: `https://{your-environment-id}.live.dynatrace.com`
  * **Managed**: `https://{your-domain}/e/{your-environment-id}`
* The [PaaS token] of your environment

We recommend that you store both the PAAS-token and the environment-id securely, using encryption mechanisms such as Ansible Vault.
For details, see [Encrypting content with Ansible Vault].

### Option 2: Use local installers

Use the Dynatrace web UI to download the required OneAgent installer files and then upload them to the control node.
Use the `oneagent_local_installer` variable to supply the role with the path of the installer file. For example:

```yaml
oneagent_local_installer: /path/of/oneagent_linux_installer.sh
```

The script copies the installer files to the managed nodes during execution.  

Note that Windows, Linux, and AIX require their dedicated installers. The original installer names, as downloaded from Dynatrace, include target platform designations. If you change the installer names, make sure the script can distinguish them.
If you don't specify the installer, the script attempts to use the direct download method.

## Configure existing OneAgents

The role is capable of configuring a currently installed OneAgent, by utilizing the `oneagentctl` command.
There are two ways of applying a new configuration to an existing OneAgent:
- If OneAgent of the same or higher version is installed on the specified host, no installation will be performed and the script will use the provided installation parameters to run the `oneagentctl` command, skipping the installation part of the procedure.
- Similarly, if no download information is provided (that is, if no `environment_url`, `paas_token` and `local_installer` parameters are provided), the script will not attempt an installation, but will only run the `oneagentctl` command with the parameters provided. 

Note that the script does not automatically supply the `--restart-service` option to the `oneagentctl` command.
For the full list of available parameters, see [OneAgent configuration via command-line interface].

## Variables

The following variables are available in `defaults/main/` and can be overridden:

| Name | Default | Description
|-|-|-
| `oneagent_environment_url` | `-` | The URL of the target Dynatrace environment (SaaS or Managed).
| `oneagent_paas_token` | `-` | The [PaaS Token] retrieved from the "Deploy Dynatrace" installer page.
| `oneagent_local_installer` | `-` | The path of the OneAgent installer stored on the control node.
| `oneagent_installer_arch` | `-` | The OneAgent installer architecture.
| `oneagent_version` | `latest` | The required version of the OneAgent in the `1.199.247.20200714-111723` format. See [Deployment API - GET available versions of OneAgent] for more details.
| `oneagent_download_dir` | Linux: `$TEMP` or `/tmp`</br>Windows: `%TEMP%` or `C:\Windows\Temp` | The installer download directory. For Linux and AIX, the directory must not contain spaces. The directory will be created if it does not exist.
| `oneagent_install_args` | `-` | Dynatrace OneAgent installation parameters defined as a list of items.
| `oneagent_platform_install_args` | `-` | Additional list of platform-specific installation parameters, appended to `oneagent_install_args' when run on the respective platform.
| `oneagent_preserve_installer` | `false` | Option to preserve the installer on the managed node after OneAgent installation.
| `oneagent_package_state` | `present` | Desired OneAgent package state. Specify `present` or `latest` to install. Specify `absent` to uninstall.
| `oneagent_reboot_host` | `false` | Option to reboot the managed node after OneAgent installation
| `oneagent_validate_certs` | `true` | Option to require certificates. If set to `false`, allows to download OneAgent from a server with insecure SSL certificate (expired, self-signed, etc).
| `oneagent_reboot_timeout` | `3600` | The timeout, in seconds, for rebooting the managed node.

For more information, see customize OneAgent installation documentation for [Linux], [Windows], and [AIX].

## Logging

The logs produced by Ansible can be collected into a single file located on the managed node, instead of being printed to STDOUT.
There are several ways to achieve this using Ansible's configuration setting:

- Set the `ANSIBLE_LOG_PATH` environment variable to the path of the log file.
- Specify the `log_path` variable in the `[default]` section of Ansible's [configuration settings file].

The verbosity of the logs can be controlled with the '-v' command line option.
Repeating the option multiple times increases the verbosity level up to the connection debugging level: `-vvvv`.

## Examples

You can find example playbooks in the `examples` directory within the role. The directory contains the following:
- `local_installer` - OneAgent installation using a local installer.
- `advanced_config` - Oneagent installation with a custom install path and a download directory.
- `oneagentctl_config` - OneAgent configuration with oneagentctl.

In addition, each directory contains an inventory file with a basic host configuration for playbooks.

__NOTE:__ For multi-platform deployment on Windows, Linux or AIX, you must specify the `become: true` option for the appropriate machine group in the inventory file.
On Windows the `become: true` option is not supported.
For path issues when installing on Windows, review [Path Formatting for Windows]

## License

Licensed under the MIT License.

## Support

For technical support contact our [Dynatrace Support].

[Dynatrace Support]: https://www.dynatrace.com/support/contact-support/
[PaaS token]: https://www.dynatrace.com/support/help/shortlink/token#paas-token-
[Deployment API]: https://www.dynatrace.com/support/help/shortlink/api-deployment
[Deployment API - GET available versions of OneAgent]: https://www.dynatrace.com/support/help/shortlink/api-deployment-get-versions
[Path Formatting for Windows]: https://docs.ansible.com/ansible/latest/user_guide/windows_usage.html#path-formatting-for-windows
[Windows]: https://www.dynatrace.com/support/help/shortlink/windows-custom-installation
[Linux]: https://www.dynatrace.com/support/help/shortlink/linux-custom-installation
[AIX]: https://www.dynatrace.com/support/help/shortlink/aix-custom-installation
[configuration settings file]: https://docs.ansible.com/ansible/latest/reference_appendices/general_precedence.html#configuration-settings
[Encrypting content with Ansible Vault]: https://docs.ansible.com/ansible/latest/user_guide/vault.html
